import { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import toast from 'react-hot-toast'
import { AlertTriangle, CheckCircle, XCircle, Loader, Image, Trash2, CalendarClock, RotateCcw } from 'lucide-react'
import { apiErrorMessage, getPlan, listPosts, approvePost, deletePlan, regeneratePlan } from '../api/client'
import ImageLightbox from '../components/ImageLightbox'
import CampaignPipeline from '../components/CampaignPipeline'

function formatWhen(iso) {
  try { return new Date(iso).toLocaleString('ar', { dateStyle: 'medium', timeStyle: 'short' }) }
  catch { return iso }
}

// الهوك يُعرض بخط عريض فوق النص، والكابشن غالباً يبدأ بنفسه — نحذف التكرار
// حتى لا تظهر الجملة الافتتاحية مرتين (عريضة ثم عادية).
function captionWithoutHook(caption, hook) {
  const body = (caption || '').trim()
  const head = (hook || '').trim()
  if (!body || !head) return body
  const norm = s => s.replace(/\s+/g, ' ').trim()
  if (norm(body).startsWith(norm(head))) {
    // نقصّ بمقارنة تدريجية لتجاوز فروق المسافات/الأسطر
    let i = 0, j = 0
    while (i < body.length && j < head.length) {
      if (/\s/.test(body[i]) && /\s/.test(head[j])) {
        while (i < body.length && /\s/.test(body[i])) i++
        while (j < head.length && /\s/.test(head[j])) j++
        continue
      }
      if (body[i] !== head[j]) break
      i++; j++
    }
    if (j >= head.length) {
      return body.slice(i).replace(/^[\s‏‎:،.-]+/, '').trim()
    }
  }
  return body
}

const STATUS_BADGE = {
  approved: 'bg-emerald-50 text-emerald-700',
  rejected: 'bg-red-50 text-red-700',
  reviewing: 'bg-amber-50 text-amber-700',
  draft: 'bg-gray-100 text-gray-600',
}

export default function CampaignDetailPage() {
  const { id } = useParams()
  const planId = parseInt(id)
  const qc = useQueryClient()
  const navigate = useNavigate()
  const [zoom, setZoom] = useState(null)

  const { data: plan } = useQuery({
    queryKey: ['plan', planId],
    queryFn: () => getPlan(planId).then(r => r.data),
    // pipeline_state خفيف أثناء التنفيذ ويعطي انتقالات الوكلاء شبه لحظياً.
    refetchInterval: (query) => {
      const currentPlan = query.state.data
      if (!['pending', 'generating'].includes(currentPlan?.status)) return false
      return currentPlan?.pipeline_state?.is_demo ? 600 : 1500
    },
    refetchIntervalInBackground: true,
  })

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ['posts', planId],
    queryFn: () => listPosts(planId).then(r => r.data),
    refetchInterval: plan?.status === 'generating'
      ? (plan?.pipeline_state?.is_demo ? 800 : 2500)
      : false,
  })

  const approveMutation = useMutation({
    mutationFn: ({ postId, approved }) => approvePost(postId, approved),
    onSuccess: (_res, { approved }) => {
      qc.invalidateQueries({ queryKey: ['posts', planId] })
      qc.invalidateQueries({ queryKey: ['scheduled'] })
      if (approved) toast.success('تم الاعتماد وجُدول تلقائياً على وقت الذروة (8 مساءً) 🗓️')
    },
    onError: (error) => toast.error(apiErrorMessage(error, 'تعذّر تحديث حالة المنشور')),
  })

  const deleteMutation = useMutation({
    mutationFn: () => deletePlan(planId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['plans'] })
      toast.success('تم حذف الحملة')
      navigate('/campaigns')
    },
    onError: (error) => toast.error(apiErrorMessage(error, 'فشل حذف الحملة')),
  })

  const regenerateMutation = useMutation({
    mutationFn: () => regeneratePlan(planId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['plan', planId] })
      qc.invalidateQueries({ queryKey: ['posts', planId] })
      qc.invalidateQueries({ queryKey: ['plans'] })
      toast.success('بدأت إعادة توليد الحملة')
    },
    onError: (error) => toast.error(apiErrorMessage(error, 'تعذرت إعادة توليد الحملة')),
  })

  const handleDelete = () => {
    if (window.confirm('هل أنتِ متأكدة من حذف هذه الحملة وجميع منشوراتها؟')) {
      deleteMutation.mutate()
    }
  }

  const handleRegenerate = () => {
    const confirmed = window.confirm(
      'ستُحذف النتائج الجزئية غير المعتمدة من المحاولة الفاشلة، ثم ستُولّد الحملة من جديد. هل تريد المتابعة؟'
    )
    if (confirmed) regenerateMutation.mutate()
  }

  const approvedCount = posts.filter(p => p.approved).length
  const isGenerating = plan?.status === 'generating'

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {plan?.campaign_name || `حملة #${planId}`}
            </h1>
            <p className="text-gray-500 mt-1">{plan?.days} أيام</p>
          </div>
          <div className="flex items-center gap-3">
            {isGenerating && (
              <div className="flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-xl text-sm font-semibold">
                <Loader size={16} className="animate-spin" />
                جاري التوليد...
              </div>
            )}
            <button
              onClick={handleDelete}
              disabled={deleteMutation.isPending}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-red-600 bg-red-50 hover:bg-red-100 transition-colors disabled:opacity-50"
            >
              <Trash2 size={16} />
              {deleteMutation.isPending ? 'جاري الحذف...' : 'حذف الحملة'}
            </button>
          </div>
        </div>

        {/* غرفة عمليات الوكلاء — تبقى ظاهرة بعد الاكتمال كسجل قابل للتتبّع */}
        {plan && (
          <div className="mt-5">
            <CampaignPipeline
              pipeline={plan?.pipeline_state}
              stage={plan?.current_stage}
              status={plan?.status}
              errorMessage={plan?.error_message}
              postsGenerated={posts.length}
            />
          </div>
        )}

        {/* Progress bar */}
        {posts.length > 0 && (
          <div className="mt-4 p-4 bg-gray-50 rounded-xl">
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>{approvedCount} منشور معتمد من {posts.length}</span>
              <span>{Math.round((approvedCount / posts.length) * 100)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-emerald-500 h-2 rounded-full transition-all" style={{ width: `${(approvedCount / posts.length) * 100}%` }} />
            </div>
          </div>
        )}
      </div>

      {/* تفاصيل الفشل معروضة على العقدة المتعطّلة في خط الأنابيب أعلاه */}
      {plan?.status === 'failed' && (
        <div className="mb-6 flex justify-center">
          <button
            type="button"
            onClick={handleRegenerate}
            disabled={regenerateMutation.isPending}
            className="inline-flex items-center gap-2 rounded-xl bg-red-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {regenerateMutation.isPending
              ? <Loader size={16} className="animate-spin" />
              : <RotateCcw size={16} />}
            {regenerateMutation.isPending ? 'جاري بدء المحاولة...' : 'إعادة توليد الحملة'}
          </button>
        </div>
      )}

      {plan?.status === 'done_with_errors' && (
        <div className="mb-6 rounded-xl border border-amber-200 bg-amber-50 p-4 text-amber-900 flex items-start gap-3">
          <AlertTriangle size={20} className="mt-0.5 flex-shrink-0"/>
          <div>
            <p className="font-bold">اكتملت الحملة جزئياً</p>
            <p className="text-sm mt-1 leading-6">
              تم حفظ المنشورات التي اكتملت بنجاح فقط. راجعها قبل الاعتماد.
            </p>
            {plan.error_message && (
              <p className="text-xs mt-2 text-amber-700 break-words">{plan.error_message}</p>
            )}
          </div>
        </div>
      )}

      {isGenerating && posts.length === 0 && (
        <p className="mb-6 text-center text-sm text-gray-400">ستظهر المنشورات هنا تدريجياً بعد حفظ أول نتيجة.</p>
      )}

      {/* Posts grid */}
      {posts.length > 0 && (
        <div className="space-y-6">
          {posts.map(post => (
            <div key={post.id} className={`card border-2 transition-all ${post.approved ? 'border-emerald-200' : 'border-transparent'}`}>
              <div className="flex items-start gap-4">
                {/* Image */}
                <div className="flex-shrink-0 w-40 h-40 bg-gray-100 rounded-xl overflow-hidden">
                  {post.image_url ? (
                    <img
                      src={post.image_url}
                      alt="Post"
                      className="w-full h-full object-cover cursor-zoom-in hover:opacity-90 transition-opacity"
                      onClick={() => setZoom(post.image_url)}
                      onError={(e) => {
                        e.target.style.display = 'none'
                        e.target.nextSibling.style.display = 'flex'
                      }}
                    />
                  ) : null}
                  <div
                    className="w-full h-full flex-col items-center justify-center text-gray-400 text-xs text-center p-2 gap-1"
                    style={{ display: post.image_url ? 'none' : 'flex' }}
                  >
                    <Image size={28} className="opacity-40" />
                    <span>{post.image_url ? 'تعذّر تحميل الصورة' : 'لا توجد صورة'}</span>
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-bold text-primary-600 bg-primary-50 px-2 py-0.5 rounded-full">
                      اليوم {post.day_number}
                    </span>
                    <span className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">
                      {post.post_type}
                    </span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_BADGE[post.status] || STATUS_BADGE.draft}`}>
                      {post.status === 'approved' ? 'معتمد' : post.status === 'rejected' ? 'مرفوض' : 'قيد المراجعة'}
                    </span>
                    {post.intelligence_status && post.intelligence_status !== 'not_evaluated' && (
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${post.intelligence_status === 'ready_for_human_review' ? 'bg-indigo-50 text-indigo-700' : 'bg-orange-50 text-orange-700'}`}>
                        {post.intelligence_status === 'ready_for_human_review' ? 'اجتاز بوابات الذكاء' : 'يحتاج تدقيقاً إضافياً'}
                      </span>
                    )}
                  </div>

                  {post.candidate_results?.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-2 text-xs text-gray-500">
                      <span className="bg-gray-50 px-2 py-1 rounded-lg">3 مرشحين موثّقين</span>
                      {post.predesign_score != null && <span className="bg-blue-50 text-blue-700 px-2 py-1 rounded-lg">قبل التصميم: {(post.predesign_score * 100).toFixed(1)}%</span>}
                      {post.multimodal_score != null && <span className="bg-violet-50 text-violet-700 px-2 py-1 rounded-lg">بعد التصميم: {(post.multimodal_score * 100).toFixed(1)}%</span>}
                      {post.predesign_score == null && <span className="bg-amber-50 text-amber-700 px-2 py-1 rounded-lg">Cold Start: بلا احتمال ادّعائي</span>}
                    </div>
                  )}

                  {post.hook && (
                    <p className="font-bold text-gray-900 text-sm mb-1">🎯 {post.hook}</p>
                  )}

                  {captionWithoutHook(post.caption, post.hook) && (
                    <p className="text-gray-700 text-sm leading-relaxed whitespace-pre-wrap line-clamp-4">
                      {captionWithoutHook(post.caption, post.hook)}
                    </p>
                  )}

                  {post.cta && (
                    <p className="text-primary-600 font-semibold text-sm mt-2">👉 {post.cta}</p>
                  )}

                  {post.hashtags?.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {post.hashtags.slice(0, 6).map(tag => (
                        <span key={tag} className="text-xs text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">#{tag.replace('#', '')}</span>
                      ))}
                    </div>
                  )}

                  {post.approved && post.scheduled_at && (
                    <p className="inline-flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 mt-2 px-2 py-1 rounded-full font-medium">
                      <CalendarClock size={12} /> مجدول: {formatWhen(post.scheduled_at)}
                    </p>
                  )}
                </div>

                {/* Approval buttons */}
                <div className="flex flex-col gap-2 flex-shrink-0">
                  <button
                    onClick={() => approveMutation.mutate({ postId: post.id, approved: true })}
                    disabled={approveMutation.isPending}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold transition-all
                      ${post.approved ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'}`}
                  >
                    <CheckCircle size={16} />
                    اعتماد
                  </button>
                  <button
                    onClick={() => approveMutation.mutate({ postId: post.id, approved: false })}
                    disabled={approveMutation.isPending}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold transition-all
                      ${!post.approved && post.status === 'rejected' ? 'bg-red-600 text-white' : 'bg-red-50 text-red-600 hover:bg-red-100'}`}
                  >
                    <XCircle size={16} />
                    رفض
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <ImageLightbox src={zoom} onClose={() => setZoom(null)} />
    </div>
  )
}

